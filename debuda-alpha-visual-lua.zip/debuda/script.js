const games = [
 {id:'roblox',name:'Roblox',category:'Action',description:'Explore millions of experiences made by a global community.',emoji:'🟥',art:'roblox',tag:'POPULAR'},
 {id:'geometry',name:'Geometry Dash',category:'Casual',description:'Jump, fly, and flip your way through rhythm-based levels.',emoji:'🔶',art:'geometry',tag:'RHYTHM'},
 {id:'minecraft',name:'Minecraft',category:'Adventure',description:'Build, explore, and create your own blocky world.',emoji:'🟩',art:'minecraft',tag:'SANDBOX'},
 {id:'velocity',name:'Velocity X',category:'Action',description:'A fast arcade racing concept for the Debuda collection.',emoji:'🏎️',art:'racing',tag:'COMING SOON'},
 {id:'deep-space',name:'Deep Space',category:'Adventure',description:'A space exploration concept from the Debuda collection.',emoji:'🚀',art:'space',tag:'COMING SOON'},
 {id:'puzzle-world',name:'Puzzle World',category:'Casual',description:'A colorful puzzle concept for a relaxed game break.',emoji:'🧩',art:'puzzle',tag:'COMING SOON'}
];
const plans={day:{label:'PER DAY',price:'€1.49'},week:{label:'PER WEEK',price:'€4.99'},month:{label:'PER MONTH',price:'€9.99'},year:{label:'PER YEAR',price:'€49.99'},lifetime:{label:'ONE-TIME',price:'€79.99'}};
let selectedPlan='day',saved=new Set(),activeFilter='All',activeGame=null;
const $=s=>document.querySelector(s);
function toast(message){const t=$('#toast');t.textContent=message;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),2400)}
function card(game){return `<article class="game-card" data-game="${game.id}"><div class="game-thumb thumb-${game.art}"><span>${game.emoji}</span></div><div class="game-content"><h3>${game.name}</h3><p>${game.description}</p><div class="game-bottom"><span>${game.category} · ${game.tag}</span><b>View details ↗</b></div></div></article>`}
function renderFeatured(){ $('#featuredGrid').innerHTML=games.slice(0,3).map(card).join(''); }
function renderCatalog(){const q=$('#searchInput').value.trim().toLowerCase();const list=games.filter(g=>(activeFilter==='All'||g.category===activeFilter)&&`${g.name} ${g.category} ${g.description}`.toLowerCase().includes(q));$('#catalogGrid').innerHTML=list.map(card).join('');$('#gameCount').textContent=`${list.length} GAMES`;$('#noResults').classList.toggle('hidden',list.length>0);}
function renderLibrary(){const list=games.filter(g=>saved.has(g.id));$('#libraryGrid').innerHTML=list.map(card).join('');$('.library-empty').classList.toggle('hidden',list.length>0);}
function go(view){['home','games','library'].forEach(v=>$(`#${v}View`).classList.toggle('hidden',v!==view));document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));$('#crumbName').textContent=view==='home'?'Home':view==='games'?'Games':'My library';$('#sidebar').classList.remove('open');if(view==='games')renderCatalog();if(view==='library')renderLibrary();window.scrollTo({top:0,behavior:'smooth'});}
function openModal(id){$('#'+id).classList.remove('hidden');document.body.style.overflow='hidden';}
function closeModal(id){$('#'+id).classList.add('hidden');if(document.querySelectorAll('.modal-backdrop:not(.hidden)').length===0)document.body.style.overflow='';}
function openGame(id){const game=games.find(g=>g.id===id);if(!game)return;activeGame=game;$('#modalTitle').textContent=game.name;$('#modalCategory').textContent=`${game.category.toUpperCase()} · ${game.tag}`;$('#modalDescription').textContent=game.description;$('#modalEmoji').textContent=game.emoji;$('#modalArt').className=`modal-art thumb-${game.art}`;$('#modalSaveBtn').textContent=saved.has(id)?'★ Saved':'☆ Save game';openModal('gameModal');}
function openShop(){closeModal('gameModal');openModal('shopModal');}
function choosePlan(plan){selectedPlan=plan;document.querySelectorAll('.plan').forEach(b=>b.classList.toggle('selected',b.dataset.plan===plan));$('#priceLabel').textContent=plans[plan].label;$('#planPrice').textContent=plans[plan].price;}
$('#enterBtn').addEventListener('click',()=>{$('#welcomeScreen').classList.add('hidden');$('#app').classList.remove('hidden');});
document.addEventListener('click',e=>{const nav=e.target.closest('[data-view]');if(nav){go(nav.dataset.view);return;}const goBtn=e.target.closest('[data-go]');if(goBtn){go(goBtn.dataset.go);return;}const game=e.target.closest('[data-game]');if(game){openGame(game.dataset.game);return;}const close=e.target.closest('[data-close]');if(close){closeModal(close.dataset.close);return;}const plan=e.target.closest('[data-plan]');if(plan){choosePlan(plan.dataset.plan);return;}const filter=e.target.closest('[data-filter]');if(filter){activeFilter=filter.dataset.filter;document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b===filter));renderCatalog();}});
$('#sidebarBuy').addEventListener('click',openShop);$('#bannerBuy').addEventListener('click',openShop);$('#modalAlphaBtn').addEventListener('click',openShop);
$('#modalSaveBtn').addEventListener('click',()=>{if(!activeGame)return;if(saved.has(activeGame.id)){saved.delete(activeGame.id);toast('Removed from your library.');}else{saved.add(activeGame.id);toast('Saved to your library.');}$('#modalSaveBtn').textContent=saved.has(activeGame.id)?'★ Saved':'☆ Save game';renderLibrary();});
$('#buyNow').addEventListener('click',()=>toast(`You selected Debuda Alpha — ${selectedPlan}. Checkout is not connected yet.`));
$('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#searchInput').addEventListener('input',()=>{if($('#gamesView').classList.contains('hidden'))go('games');renderCatalog();});
document.querySelectorAll('.modal-backdrop').forEach(backdrop=>backdrop.addEventListener('click',e=>{if(e.target===backdrop)closeModal(backdrop.id);}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelectorAll('.modal-backdrop:not(.hidden)').forEach(m=>closeModal(m.id));$('#sidebar').classList.remove('open');}});
renderFeatured();renderCatalog();choosePlan('day');
