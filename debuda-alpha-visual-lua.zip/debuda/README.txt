DEBUDA ALPHA 1.1 — STATIC WEBSITE

FILES
- index.html: pages and modal layouts
- style.css: dark purple responsive design
- script.js: navigation, game cards, search, library, plan selector
- debudalogo.png: Debuda logo used as the site icon and in the UI
- vercel.json: Vercel static-site settings

PREVIEW LOCALLY
Open index.html in a browser. You can also use VS Code Live Server.

DEPLOY TO VERCEL
1. Upload all files in this folder to a GitHub repository.
2. In Vercel, choose Add New -> Project and import the repository.
3. Choose Framework Preset: Other.
4. Leave Build Command and Output Directory empty.
5. Click Deploy.

IMPORTANT
The Alpha shop is a front-end demo. The prices are example prices only, and no payment is collected. To accept real payments, connect a payment provider and a secure server-side checkout. The game tiles are clickable UI examples; actual game launch URLs still need to be configured. The saved library lasts only until the page is refreshed.
